import pygame

def check_collision(rect1, rect2):
    return rect1.colliderect(rect2)
