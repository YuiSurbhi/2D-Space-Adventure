# Game settings
WIDTH = 800
HEIGHT = 600
FPS = 60
